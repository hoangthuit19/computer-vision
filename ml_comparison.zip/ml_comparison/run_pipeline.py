#!/usr/bin/env python3
"""
Text Correction ML Pipeline
Pipeline that runs Baseline OCR + Text Correction ML
"""

import os
import sys
import time
import pandas as pd
from datetime import datetime

# Import our modules
sys.path.append('..')
from run_baseline import BaselineOCRRunner
from text_correction_ml import SimpleTextCorrectionML
from text_normalizer import TextNormalizer
from base_ocr import BaseOCRProcessor
from common_utils import is_numeric_equal, GT_FIELD_MAPPING, FIELDS_TO_CHECK

class TextCorrectionPipeline(BaseOCRProcessor):
    def __init__(self):
        super().__init__()
        self.baseline_runner = BaselineOCRRunner()
        self.correction_ml = SimpleTextCorrectionML()
        
    # load_ground_truth method is now inherited from BaseOCRProcessor
    
    def run_baseline_phase(self, images_dir="../images", gt_data=None):
        """Phase 1: Run Baseline OCR"""
        print("\n" + "=" * 60)
        print("🚀 PHASE 1: BASELINE OCR")
        print("=" * 60)
        
        print("📸 Running Baseline OCR...")
        
        # Run baseline OCR - only first 5 images for testing
        results, accuracy = self.baseline_runner.run_baseline_ocr(
            image_folder=images_dir + '/',
            ground_truth_file='../data.csv',
            limit=5  # Process only first 5 images for testing
        )
        
        # Convert results
        baseline_results = []
        for result in self.baseline_runner.results:
            gt_raw = result['ground_truth']
            gt_converted = {
                'student_name': str(gt_raw.get('Student Name', '')).strip(),
                'student_id': str(gt_raw.get('Student ID', '')).strip(),
                'vehicle_plate': str(gt_raw.get('Vehicle Plate', '')).strip(),
                'instructor_name': str(gt_raw.get('Instructor Name', '')).strip(),
                'distance_completed': str(gt_raw.get('Distance Completed (km)', '')).strip(),
                'time_completed': str(gt_raw.get('Time Completed', '')).strip(),
                'distance_remaining': str(gt_raw.get('Distance Remaining (km)', '')).strip(),
                'time_remaining': str(gt_raw.get('Time Remaining', '')).strip(),
                'total_sessions': str(gt_raw.get('Total Sessions', '')).strip()
            }
            
            converted_result = {
                'image_name': result['image_name'],
                'processing_time': 0,
                'ground_truth': gt_converted
            }
            
            # Add predicted fields
            for field in ['student_name', 'student_id', 'vehicle_plate', 'instructor_name',
                         'distance_completed', 'time_completed', 'distance_remaining',
                         'time_remaining', 'total_sessions']:
                converted_result[field] = result.get(field, '')
            
            baseline_results.append(converted_result)
        
        print(f"\n🎉 Baseline phase completed")
        print(f"📊 Processed {len(baseline_results)} images")
        
        return baseline_results
    
    def run_correction_phase(self, baseline_results):
        """Phase 2: Apply Text Correction ML"""
        print("\n" + "=" * 60)
        print("🧠 PHASE 2: TEXT CORRECTION ML")
        print("=" * 60)
        
        print("🤖 Training Text Correction ML...")
        
        # Train correction model
        training_data = self.correction_ml.create_training_data()
        if training_data:
            self.correction_ml.train(training_data)
            # Save trained model
            self.correction_ml.save_model()
        else:
            print("❌ No training data available")
            return baseline_results
        
        print("🔧 Applying text correction to baseline results...")
        
        # Apply correction
        corrected_results = self.correction_ml.correct_baseline_results(baseline_results)
        
        print(f"\n🎉 Correction phase completed")
        print(f"📊 Corrected {len(corrected_results)} results")
        
        return corrected_results
    
    # calculate_accuracy method is now inherited from BaseOCRProcessor
    
    def save_results(self, results, accuracy, processing_time, model_name):
        """Save results to CSV and summary"""
        if not results:
            print("❌ No results to save")
            return
        
        # Fixed filenames - overwrite each time
        if "baseline" in model_name.lower():
            csv_filename = "baseline_results.csv"
            summary_filename = "baseline_summary.txt"
        else:
            csv_filename = "enhanced_results.csv"
            summary_filename = "enhanced_summary.txt"
        
        # Save detailed CSV
        self.save_detailed_results(results, csv_filename, model_name=model_name)
        
        # Save summary
        self.save_summary(results, accuracy, summary_filename, processing_time)
        
        print(f"\n📁 Results saved:")
        print(f"  - Detailed CSV: {csv_filename}")
        print(f"  - Summary: {summary_filename}")
        print(f"  - Accuracy: {accuracy:.2f}%")
    
    # save_csv method is now replaced by save_detailed_results from BaseOCRProcessor
    
    # save_summary method is now inherited from BaseOCRProcessor

def main():
    """Main execution function"""
    print("🚀 Starting Text Correction ML Pipeline...")
    
    pipeline = TextCorrectionPipeline()
    
    # Load ground truth
    gt_data = pipeline.load_ground_truth()
    
    # Phase 1: Baseline OCR
    start_time = time.time()
    baseline_results = pipeline.run_baseline_phase(gt_data=gt_data)
    baseline_time = time.time() - start_time
    
    # Calculate baseline accuracy using DataFrame
    import pandas as pd
    gt_df = pd.read_csv('../data.csv', sep=';')
    baseline_accuracy = pipeline.calculate_accuracy(baseline_results, gt_df)
    
    # Save baseline results
    pipeline.save_results(baseline_results, baseline_accuracy, baseline_time, "baseline_ocr")
    
    # Phase 2: Text Correction ML
    start_time = time.time()
    corrected_results = pipeline.run_correction_phase(baseline_results)
    correction_time = time.time() - start_time
    
    # Calculate corrected accuracy using DataFrame
    corrected_accuracy = pipeline.calculate_accuracy(corrected_results, gt_df)
    
    # Save corrected results
    pipeline.save_results(corrected_results, corrected_accuracy, correction_time, "text_correction_ml")
    
    print("\n" + "=" * 60)
    print("🎯 PIPELINE COMPLETED!")
    print("=" * 60)
    print(f"📊 Baseline OCR: {baseline_accuracy:.2f}% accuracy")
    print(f"🧠 Text Correction ML: {corrected_accuracy:.2f}% accuracy")
    print(f"📈 Improvement: {corrected_accuracy - baseline_accuracy:+.2f}%")
    print("📁 Check generated CSV and summary files for detailed results")
    print("=" * 60)

if __name__ == "__main__":
    main()
