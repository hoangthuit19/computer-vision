#!/usr/bin/env python3
"""
Run Baseline OCR Model Only - Clean Version
"""

import os
import sys
import time
import pandas as pd
import numpy as np
from datetime import datetime

# Import our modules
try:
    sys.path.append('..')
    from main_ocr import SimpleOCRProcessor
    from text_normalizer import TextNormalizer
    from base_ocr import BaseOCRProcessor
    from common_utils import is_numeric_equal, GT_FIELD_MAPPING, FIELDS_TO_CHECK
except ImportError as e:
    print(f"Import error: {e}")
    print("Please make sure main_ocr.py is in the parent directory")
    sys.exit(1)

class BaselineOCRRunner(BaseOCRProcessor):
    def __init__(self):
        super().__init__()
        
    def run_baseline_ocr(self, image_folder='../images/', ground_truth_file='../data.csv', limit=20):
        """Run baseline OCR on specified number of images"""
        print("="*60)
        print("RUNNING BASELINE OCR MODEL")
        print("="*60)
        
        self.start_time = time.time()
        
        # Load ground truth
        print("Loading ground truth data...")
        gt_df = pd.read_csv(ground_truth_file, sep=';')
        # Clean column names
        gt_df.columns = gt_df.columns.str.strip()
        print(f"Loaded {len(gt_df)} ground truth records")
        
        # Initialize processor
        print("Initializing PaddleOCR...")
        processor = SimpleOCRProcessor()
        processor.set_template('../dat_template.png')
        print("OCR initialized successfully!")
        
        # Process images
        print(f"Processing first {limit} images...")
        results = []
        gt_df_limited = gt_df.head(limit)
        
        for idx, row in gt_df_limited.iterrows():
            image_name = row['Image Name']
            image_path = os.path.join(image_folder, f"{image_name}.jpg")
            
            print(f"Processing {image_name} ({idx+1}/{limit})...")
            
            if os.path.exists(image_path):
                try:
                    result = processor.process_single_image(image_path)
                    result['image_name'] = image_name
                    result['ground_truth'] = row.to_dict()
                    results.append(result)
                except Exception as e:
                    print(f"Error processing {image_name}: {e}")
                    results.append({
                        'image_name': image_name,
                        'ground_truth': row.to_dict(),
                        'error': str(e)
                    })
            else:
                print(f"Image not found: {image_path}")
                results.append({
                    'image_name': image_name,
                    'ground_truth': row.to_dict(),
                    'error': 'Image not found'
                })
        
        self.end_time = time.time()
        self.results = results
        
        # Calculate accuracy
        accuracy = self.calculate_accuracy(results, gt_df)
        
        # Save results
        self.save_results(results, accuracy)
        
        print(f"\nBaseline OCR completed in {self.end_time - self.start_time:.2f} seconds")
        print(f"Accuracy: {accuracy:.2f}%")
        
        return results, accuracy
    
    # calculate_accuracy method is now inherited from BaseOCRProcessor
    
    def save_results(self, results, accuracy):
        """Save results to CSV and summary files"""
        # Use fixed filenames - no timestamp
        csv_filename = "baseline_results.csv"
        summary_filename = "baseline_summary.txt"
        
        # Save detailed results CSV
        self.save_detailed_results(results, csv_filename, model_name='baseline_ocr')
        
        # Save summary
        self.save_summary(results, accuracy, summary_filename)
        
        print(f"\nResults saved:")
        print(f"  - Detailed CSV: {csv_filename}")
        print(f"  - Summary: {summary_filename}")
    
    # save_detailed_results method is now inherited from BaseOCRProcessor
    
    # save_summary method is now inherited from BaseOCRProcessor
    
    # calculate_field_accuracy method is now inherited from BaseOCRProcessor

def main():
    """Main function to run baseline OCR"""
    runner = BaselineOCRRunner()
    results, accuracy = runner.run_baseline_ocr(limit=100)
    
    print(f"\n🎉 Baseline OCR completed!")
    print(f"📊 Overall Accuracy: {accuracy:.2f}%")
    print(f"📁 Results saved to CSV and summary files")

if __name__ == "__main__":
    main()
