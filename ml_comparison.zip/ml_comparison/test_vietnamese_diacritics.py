import easyocr
import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont
import unicodedata
import re

class VietnameseDiacriticsTest:
    def __init__(self):
        # Khởi tạo EasyOCR với tiếng Việt
        self.reader = easyocr.Reader(['vi', 'en'], gpu=False)
        
    def create_test_image(self, text, font_size=40):
        """Tạo ảnh test với text tiếng Việt"""
        # Tạo ảnh trắng
        img = Image.new('RGB', (800, 200), color='white')
        draw = ImageDraw.Draw(img)
        
        try:
            # Thử sử dụng font hỗ trợ tiếng Việt
            font = ImageFont.truetype("arial.ttf", font_size)
        except:
            font = ImageFont.load_default()
            
        # Vẽ text lên ảnh
        draw.text((50, 50), text, fill='black', font=font)
        
        # Chuyển sang numpy array
        return np.array(img)
    
    def test_diacritics_detection(self):
        """Test các dấu tiếng Việt"""
        test_cases = [
            "Nguyễn Văn Anh",
            "Trần Thị Hương", 
            "Lê Minh Quân",
            "Phạm Thúy Hằng",
            "Đỗ Xuân Thành",
            "Hoàng Thị Liên",
            "MSSV: 20210001",
            "Biển số: 30A-12345",
            "Địa chỉ: Hà Nội",
            "Điện thoại: 0123456789"
        ]
        
        results = []
        
        for i, text in enumerate(test_cases):
            print(f"\n--- Test {i+1}: '{text}' ---")
            
            # Tạo ảnh test
            img = self.create_test_image(text)
            
            # OCR với EasyOCR
            ocr_results = self.reader.readtext(img)
            
            # Lấy text được nhận diện
            detected_text = ""
            if ocr_results:
                detected_text = " ".join([result[1] for result in ocr_results])
            
            # So sánh
            accuracy = self.calculate_text_similarity(text, detected_text)
            diacritics_preserved = self.check_diacritics_preservation(text, detected_text)
            
            result = {
                'original': text,
                'detected': detected_text,
                'accuracy': accuracy,
                'diacritics_preserved': diacritics_preserved,
                'confidence': ocr_results[0][2] if ocr_results else 0
            }
            
            results.append(result)
            
            print(f"Gốc: {text}")
            print(f"Nhận diện: {detected_text}")
            print(f"Độ chính xác: {accuracy:.2%}")
            print(f"Dấu được bảo toàn: {diacritics_preserved}")
            
        return results
    
    def calculate_text_similarity(self, original, detected):
        """Tính độ tương đồng giữa text gốc và text nhận diện"""
        if not detected:
            return 0.0
            
        # Normalize text
        original_norm = self.normalize_text(original)
        detected_norm = self.normalize_text(detected)
        
        # Tính Levenshtein distance
        distance = self.levenshtein_distance(original_norm, detected_norm)
        max_len = max(len(original_norm), len(detected_norm))
        
        if max_len == 0:
            return 1.0
            
        return 1 - (distance / max_len)
    
    def check_diacritics_preservation(self, original, detected):
        """Kiểm tra xem các dấu tiếng Việt có được bảo toàn không"""
        original_diacritics = self.extract_diacritics(original)
        detected_diacritics = self.extract_diacritics(detected)
        
        if not original_diacritics:
            return True
            
        preserved_count = 0
        for char in original_diacritics:
            if char in detected_diacritics:
                preserved_count += 1
                
        return preserved_count / len(original_diacritics)
    
    def extract_diacritics(self, text):
        """Trích xuất các ký tự có dấu"""
        vietnamese_chars = "àáảãạăằắẳẵặâầấẩẫậèéẻẽẹêềếểễệìíỉĩịòóỏõọôồốổỗộơờớởỡợùúủũụưừứửữựỳýỷỹỵđ"
        vietnamese_chars += vietnamese_chars.upper()
        
        return [char for char in text if char in vietnamese_chars]
    
    def normalize_text(self, text):
        """Chuẩn hóa text để so sánh"""
        # Loại bỏ khoảng trắng thừa
        text = re.sub(r'\s+', ' ', text.strip())
        return text.lower()
    
    def levenshtein_distance(self, s1, s2):
        """Tính Levenshtein distance"""
        if len(s1) < len(s2):
            return self.levenshtein_distance(s2, s1)
        
        if len(s2) == 0:
            return len(s1)
        
        previous_row = list(range(len(s2) + 1))
        for i, c1 in enumerate(s1):
            current_row = [i + 1]
            for j, c2 in enumerate(s2):
                insertions = previous_row[j + 1] + 1
                deletions = current_row[j] + 1
                substitutions = previous_row[j] + (c1 != c2)
                current_row.append(min(insertions, deletions, substitutions))
            previous_row = current_row
        
        return previous_row[-1]
    
    def test_with_real_image(self, image_path):
        """Test với ảnh thật"""
        try:
            img = cv2.imread(image_path)
            if img is None:
                print(f"Không thể đọc ảnh: {image_path}")
                return
                
            results = self.reader.readtext(img)
            
            print(f"\n--- Test với ảnh thật: {image_path} ---")
            for i, (bbox, text, confidence) in enumerate(results):
                print(f"Text {i+1}: {text} (confidence: {confidence:.3f})")
                
                # Kiểm tra dấu tiếng Việt
                diacritics = self.extract_diacritics(text)
                if diacritics:
                    print(f"  Dấu tiếng Việt: {diacritics}")
                    
        except Exception as e:
            print(f"Lỗi khi xử lý ảnh: {e}")

def main():
    tester = VietnameseDiacriticsTest()
    
    print("=== TEST KHẢ NĂNG NHẬN DIỆN DẤU TIẾNG VIỆT CỦA EASYOCR ===")
    
    # Test với ảnh tự tạo
    results = tester.test_diacritics_detection()
    
    # Tính toán thống kê tổng thể
    total_accuracy = sum(r['accuracy'] for r in results) / len(results)
    total_diacritics = sum(r['diacritics_preserved'] for r in results) / len(results)
    
    print(f"\n=== TỔNG KẾT ===")
    print(f"Độ chính xác trung bình: {total_accuracy:.2%}")
    print(f"Tỷ lệ bảo toàn dấu: {total_diacritics:.2%}")
    
    # Gợi ý cải thiện
    if total_diacritics < 0.8:
        print("\n=== GỢI Ý CẢI THIỆN ===")
        print("1. Thử sử dụng preprocessing để tăng độ rõ nét")
        print("2. Điều chỉnh confidence threshold")
        print("3. Sử dụng post-processing để sửa lỗi dấu")
        print("4. Kết hợp với spell checker tiếng Việt")

if __name__ == "__main__":
    main()
