#!/usr/bin/env python3
"""
Common Utilities for OCR Pipeline
Contains shared functions, constants, and configurations
"""

def is_numeric_equal(str1, str2):
    """Check if two strings represent the same numeric value"""
    try:
        # Try to convert to float and compare
        num1 = float(str1)
        num2 = float(str2)
        return abs(num1 - num2) < 1e-9  # Handle floating point precision
    except (ValueError, TypeError):
        # If not numeric, do string comparison
        return str1 == str2

# Field mappings
GT_FIELD_MAPPING = {
    'student_name': 'Student Name',
    'student_id': 'Student ID',
    'vehicle_plate': 'Vehicle Plate',
    'instructor_name': 'Instructor Name',
    'distance_completed': 'Distance Completed (km)',
    'time_completed': 'Time Completed',
    'distance_remaining': 'Distance Remaining (km)',
    'time_remaining': 'Time Remaining',
    'total_sessions': 'Total Sessions'
}

# Fields to check for accuracy calculation
FIELDS_TO_CHECK = list(GT_FIELD_MAPPING.keys())

# Common prefixes to remove from OCR text
COMMON_PREFIXES = [
    'hv:', 'mahv:', '4v:', 's24', 'loading...', 'hang het ha', 'hang hét c1', 
    'hang', 'hét', 'c1', 'loading', 'ma hv:', 'ma hv', 'hv ', 'mahv ', '4v ',
    'mahv:79335-20250513082447007', 'adng hien trang', 'khoá: k06a c1',
    'khoá:', 'k06a', 'c1', 'hang hét', 'hang het'
]

# Vehicle plate specific prefixes
VEHICLE_PLATE_PREFIXES = [
    'HANG', 'HET', 'HA', 'GPTL', 'HANE', 'ERGOOG', 'B2', '2026', '123009'
]

# Distance specific prefixes
DISTANCE_PREFIXES = [
    'km', 'kr', 'k', 'm', 'distance', 'dist', 'd', 'le', 'hoc', 'sn la',
    'ahoc', 'ciso', 'gia', 'wd', 'ls', 'giao', 'vier', 'dem'
]

# Time specific prefixes
TIME_PREFIXES = [
    'time', 't', 'h', 'm', 's', 'hour', 'minute', 'second', 'gio', 'phut', 'giay'
]

# OCR character fixes mapping
OCR_CHAR_FIXES = {
    'o': '0', 'i': '1', 's': '5', 'b': '8', 'g': '9', 'l': '1',
    'c': '0', 'd': '0', 'e': '6', 'a': '4', 't': '7', 'n': '1',
    'm': '1', 'r': '1', 'u': '0', 'v': '1', 'w': '1', 'x': '1',
    'y': '1', 'z': '2', 'q': '9'
}

# OCR character fixes for uppercase
OCR_CHAR_FIXES_UPPER = {
    'O': '0', 'I': '1', 'S': '5', 'B': '8', 'G': '9', 'L': '1',
    'C': '0', 'D': '0', 'E': '6', 'A': '4', 'T': '7', 'N': '1',
    'M': '1', 'R': '1', 'U': '0', 'V': '1', 'W': '1', 'X': '1',
    'Y': '1', 'Z': '2', 'Q': '9'
}

# Vietnamese character normalization
VIETNAMESE_NORMALIZE = {
    'à': 'a', 'á': 'a', 'ạ': 'a', 'ả': 'a', 'ã': 'a',
    'â': 'a', 'ầ': 'a', 'ấ': 'a', 'ậ': 'a', 'ẩ': 'a', 'ẫ': 'a',
    'ă': 'a', 'ằ': 'a', 'ắ': 'a', 'ặ': 'a', 'ẳ': 'a', 'ẵ': 'a',
    'è': 'e', 'é': 'e', 'ẹ': 'e', 'ẻ': 'e', 'ẽ': 'e',
    'ê': 'e', 'ề': 'e', 'ế': 'e', 'ệ': 'e', 'ể': 'e', 'ễ': 'e',
    'ì': 'i', 'í': 'i', 'ị': 'i', 'ỉ': 'i', 'ĩ': 'i',
    'ò': 'o', 'ó': 'o', 'ọ': 'o', 'ỏ': 'o', 'õ': 'o',
    'ô': 'o', 'ồ': 'o', 'ố': 'o', 'ộ': 'o', 'ổ': 'o', 'ỗ': 'o',
    'ơ': 'o', 'ờ': 'o', 'ớ': 'o', 'ợ': 'o', 'ở': 'o', 'ỡ': 'o',
    'ù': 'u', 'ú': 'u', 'ụ': 'u', 'ủ': 'u', 'ũ': 'u',
    'ư': 'u', 'ừ': 'u', 'ứ': 'u', 'ự': 'u', 'ử': 'u', 'ữ': 'u',
    'ỳ': 'y', 'ý': 'y', 'ỵ': 'y', 'ỷ': 'y', 'ỹ': 'y',
    'đ': 'd', 'Đ': 'd'
}

# Configuration constants
SIMILARITY_THRESHOLD = 0.85
FUZZY_MATCH_THRESHOLD = 0.8
CHARACTER_SIMILARITY_THRESHOLD = 0.7
DEFAULT_TEST_LIMIT = 5
