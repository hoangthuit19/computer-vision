#!/usr/bin/env python3
"""
Test script to verify refactoring works correctly
"""

import sys
import os

def test_imports():
    """Test that all imports work correctly"""
    print("🧪 Testing imports...")
    
    try:
        from common_utils import is_numeric_equal, GT_FIELD_MAPPING, FIELDS_TO_CHECK
        print("✅ common_utils imported successfully")
    except ImportError as e:
        print(f"❌ Failed to import common_utils: {e}")
        return False
    
    try:
        from base_ocr import BaseOCRProcessor
        print("✅ base_ocr imported successfully")
    except ImportError as e:
        print(f"❌ Failed to import base_ocr: {e}")
        return False
    
    try:
        from text_normalizer import TextNormalizer
        print("✅ text_normalizer imported successfully")
    except ImportError as e:
        print(f"❌ Failed to import text_normalizer: {e}")
        return False
    
    try:
        from run_baseline import BaselineOCRRunner
        print("✅ run_baseline imported successfully")
    except ImportError as e:
        print(f"❌ Failed to import run_baseline: {e}")
        return False
    
    try:
        from run_pipeline import TextCorrectionPipeline
        print("✅ run_pipeline imported successfully")
    except ImportError as e:
        print(f"❌ Failed to import run_pipeline: {e}")
        return False
    
    return True

def test_common_utils():
    """Test common utilities functions"""
    print("\n🧪 Testing common utilities...")
    
    from common_utils import is_numeric_equal, GT_FIELD_MAPPING, FIELDS_TO_CHECK
    
    # Test is_numeric_equal
    assert is_numeric_equal("1.0", "1") == True
    assert is_numeric_equal("1.5", "1.5") == True
    assert is_numeric_equal("abc", "def") == False
    print("✅ is_numeric_equal works correctly")
    
    # Test constants
    assert len(FIELDS_TO_CHECK) == 9
    assert 'student_name' in FIELDS_TO_CHECK
    assert 'student_id' in FIELDS_TO_CHECK
    print("✅ Constants defined correctly")
    
    return True

def test_text_normalizer():
    """Test text normalizer with common constants"""
    print("\n🧪 Testing text normalizer...")
    
    from text_normalizer import TextNormalizer
    from common_utils import COMMON_PREFIXES
    
    normalizer = TextNormalizer()
    
    # Test that common prefixes are used
    test_text = "hv:12345"
    normalized = normalizer.normalize_text(test_text, field_type='student_id')
    print(f"✅ Text normalization works: '{test_text}' -> '{normalized}'")
    
    return True

def test_inheritance():
    """Test that inheritance works correctly"""
    print("\n🧪 Testing inheritance...")
    
    from run_baseline import BaselineOCRRunner
    from run_pipeline import TextCorrectionPipeline
    from base_ocr import BaseOCRProcessor
    
    # Test BaselineOCRRunner inherits from BaseOCRProcessor
    runner = BaselineOCRRunner()
    assert hasattr(runner, 'calculate_accuracy')
    assert hasattr(runner, 'save_summary')
    assert hasattr(runner, 'save_detailed_results')
    print("✅ BaselineOCRRunner inherits correctly")
    
    # Test TextCorrectionPipeline inherits from BaseOCRProcessor
    pipeline = TextCorrectionPipeline()
    assert hasattr(pipeline, 'calculate_accuracy')
    assert hasattr(pipeline, 'save_summary')
    assert hasattr(pipeline, 'load_ground_truth')
    print("✅ TextCorrectionPipeline inherits correctly")
    
    return True

def main():
    """Run all tests"""
    print("🚀 Starting Refactoring Tests...")
    print("=" * 50)
    
    tests = [
        test_imports,
        test_common_utils,
        test_text_normalizer,
        test_inheritance
    ]
    
    passed = 0
    total = len(tests)
    
    for test in tests:
        try:
            if test():
                passed += 1
        except Exception as e:
            print(f"❌ Test {test.__name__} failed: {e}")
    
    print("\n" + "=" * 50)
    print(f"🎯 Test Results: {passed}/{total} tests passed")
    
    if passed == total:
        print("🎉 All tests passed! Refactoring successful!")
        return True
    else:
        print("❌ Some tests failed. Please check the issues.")
        return False

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
